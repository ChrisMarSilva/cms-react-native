# Projeto Alugue
## Criado no youtube [Veja o video completo](https://youtu.be/cYz4bVvfPVk)

<br>

## Mockup projeto:
![](https://i.ibb.co/1L91SJv/mockup.png)

**Nossas redes:**

Instagram: [@sujeitoprogramador](https://www.instagram.com/sujeitoprogramador/)

Blog: [https://sujeitoprogramador.com](https://sujeitoprogramador.com/)

Youtube: [sujeitoprogramador](https://www.youtube.com/c/Sujeitoprogramador/)
