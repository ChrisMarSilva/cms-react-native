<img src="https://sujeitoprogramador.com/wp-content/uploads/2018/04/cropped-SujeitoP-1.png" width="300" height="100">
<h1> Código Shimmer Effect :) </h1>

## Versão react native usada: 
> react-native: 0.59.4 

## Documentação da biblioteca usada:
[ShimmerPlaceHolder](https://github.com/tomzaku/react-native-shimmer-placeholder)

# Siga nossas redes sociais:
[Facebook](https://www.facebook.com/sujeitoprogramador/)
</br>
[Instagram](https://instagram.com/sujeitoprogramador/)
</br>
[Nosso Site](https://sujeitoprogramador.com/)