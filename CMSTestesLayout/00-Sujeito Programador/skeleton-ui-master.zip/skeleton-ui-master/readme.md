<center><img src="https://sujeitoprogramador.com/wp-content/uploads/2018/04/cropped-SujeitoP-1.png"></center>

#
## Video completo no canal do youtube
[Veja o video completo](https://youtu.be/lj7pNwkmsv4)
